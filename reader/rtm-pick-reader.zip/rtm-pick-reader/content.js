// RTM Pick Reader (2026-10-19) - runs by itself on ESPN pages; wakes up only on a draft room. Read-only: never clicks anything.
(function () {
  if (window.__rtmExt) return; window.__rtmExt = 1;
  var badge = null, started = false, pend = 0, lock = null;
  function read() {
    var hdr = [].slice.call(document.querySelectorAll(".draft-board-grid-header-cell")), teams = hdr.length || 12, slot = 0;
    hdr.forEach(function (h, i) { if (/(^|[\s-])(my|own)/i.test(h.className)) slot = i + 1; });
    var all = document.querySelectorAll(".draft-board-grid-pick-cell"), rounds = all.length ? Math.round(all.length / teams) : 0;
    var picks = [].slice.call(document.querySelectorAll(".draft-board-grid-pick-cell.completedPick")).map(function (c) {
      var m = ((c.querySelector(".roundPick") || {}).textContent || "").match(/(\d+)\.(\d+)/); if (!m) return null;
      var t = function (s) { return ((c.querySelector(s) || {}).textContent || "").trim(); };
      return { n: (+m[1] - 1) * teams + (+m[2]), name: (t(".playerFirstName") + " " + t(".playerLastName")).trim(), team: t(".playerProTeam") };
    }).filter(Boolean).sort(function (a, b) { return a.n - b.n; });
    return { picks: picks, slot: slot, teams: teams, rounds: rounds, found: all.length > 0 };
  }
  function show(txt, color) {
    if (!badge) { badge = document.createElement("div"); badge.style.cssText = "position:fixed;z-index:2147483647;right:12px;bottom:12px;background:#211d17;color:#ece8df;border:2px solid #f08a3c;border-radius:8px;padding:8px 12px;font:600 13px system-ui,sans-serif;box-shadow:0 2px 10px rgba(0,0,0,.4);pointer-events:none"; document.body.appendChild(badge); }
    badge.textContent = txt; badge.style.borderColor = color;
  }
  function awake() {   // keep the Mac's screen on while the draft room is open (a sleeping screen pauses Chrome pages)
    try { if (navigator.wakeLock && !lock && document.visibilityState === "visible") navigator.wakeLock.request("screen").then(function (l) { lock = l; l.addEventListener("release", function () { lock = null; }); }).catch(function () {}); } catch (e) {}
  }
  function send() {
    var d = read();
    if (!d.found) { if (started) show("RTM: can't see ESPN's draft board - phone will warn", "#e07a6c"); return; }
    if (!started) { started = true; awake(); try { new MutationObserver(soon).observe(document.body, { subtree: true, childList: true, characterData: true }); } catch (e) {} }
    try {
      chrome.runtime.sendMessage({ type: "picks", data: d }, function (r) {
        if (chrome.runtime.lastError || !r) { show("RTM: extension restarting...", "#d9b35e"); return; }
        var s = r.stat || {};
        show(s.ok ? "RTM: " + d.picks.length + " picks sent to your phone, slot " + (d.slot || "?") : "RTM: can't reach your phone (" + (s.err || "?") + ") - retrying", s.ok ? "#7fd18b" : "#e07a6c");
      });
    } catch (e) { show("RTM: extension was updated - reload this page", "#e07a6c"); }
  }
  var lastSend = 0;   // react to ESPN's own page updates right away; don't depend on timers (Chrome slows timers in background tabs)
  function soon() { if (Date.now() - lastSend > 300) { lastSend = Date.now(); send(); } else if (!pend) pend = setTimeout(function () { pend = 0; lastSend = Date.now(); send(); }, 300); }
  document.addEventListener("visibilitychange", function () { if (started) { awake(); send(); } });
  send(); setInterval(send, 2000);
})();
