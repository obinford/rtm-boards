// RTM Pick Reader (2026-10-19) - background: owns the private phone channel and posts picks to the relay.
var RELAY = "https://bwzorxgiozrlaewrkeur.supabase.co/functions/v1/rtm-relay?ch=";
var last = { sig: "", at: 0 }, stat = { ok: false, err: "", at: 0, n: 0, slot: 0 };
function newCh() { var a = new Uint8Array(24), A = "abcdefghijklmnopqrstuvwxyz0123456789"; crypto.getRandomValues(a); return Array.prototype.map.call(a, function (x) { return A[x % 36]; }).join(""); }
async function getCh() {
  var s = await chrome.storage.local.get("ch");
  if (s.ch && /^[a-z0-9]{24}$/.test(s.ch)) return s.ch;
  var ch = newCh(); await chrome.storage.local.set({ ch: ch }); return ch;
}
chrome.runtime.onInstalled.addListener(function () { getCh(); });
chrome.runtime.onMessage.addListener(function (m, sender, reply) {
  if (m && m.type === "status") { getCh().then(function (ch) { reply({ ch: ch, stat: stat }); }); return true; }
  if (!m || m.type !== "picks" || !m.data) return;
  var d = m.data, sig = d.picks.length + ":" + d.slot + ":" + (d.picks.length ? d.picks[d.picks.length - 1].name : "");
  if (sig === last.sig && Date.now() - last.at < 4000 && stat.ok) { reply({ stat: stat }); return; }   // heartbeat at least every 4 s
  last = { sig: sig, at: Date.now() };
  getCh().then(function (ch) {
    return fetch(RELAY + ch, { method: "POST", headers: { "content-type": "text/plain" }, body: JSON.stringify({ picks: d.picks, slot: d.slot, teams: d.teams, rounds: d.rounds, age: 0 }) });
  }).then(function (r) {
    if (!r.ok) throw new Error("relay " + r.status);
    stat = { ok: true, err: "", at: Date.now(), n: d.picks.length, slot: d.slot }; reply({ stat: stat });
  }).catch(function (e) { last.sig = ""; stat = { ok: false, err: String(e.message || e), at: Date.now(), n: d.picks.length, slot: d.slot }; reply({ stat: stat }); });
  return true;
});
