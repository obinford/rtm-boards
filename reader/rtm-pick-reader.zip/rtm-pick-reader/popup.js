chrome.runtime.sendMessage({ type: "status" }, function (r) {
  var link = "https://obinford.github.io/rtm-boards/espn/?watch=" + r.ch;
  document.getElementById("link").textContent = link;
  var q = qrcode(0, "M"); q.addData(link); q.make(); document.getElementById("qr").innerHTML = q.createImgTag(4, 0);
  document.getElementById("copy").onclick = function () { navigator.clipboard.writeText(link).then(function () { document.getElementById("copy").textContent = "Copied"; }); };
  document.getElementById("backup").onclick = function () { chrome.tabs.create({ url: "https://obinford.github.io/rtm-boards/reader/#ch=" + r.ch }); };
  var s = r.stat || {};
  if (s.at) document.getElementById("st").textContent = (s.ok ? "Working: " + s.n + " picks sent to your phone " : "Problem: " + s.err + " ") + Math.round((Date.now() - s.at) / 1000) + "s ago";
});
